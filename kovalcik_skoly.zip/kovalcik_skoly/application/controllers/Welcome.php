<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

        
        public function nactiskoly()
        {
            $this->load->view('navbar');
            $this->load->view('zobrazSkoly');
        }        
        
        
        public function nactizobrazSkoly()
        {
           $this->load->model("model");
            $data["data"] = $this->model->get_skoly();
            $this->load->view('navbar');                      
            $this->load->view('zobrazSkoly', $data);
        }
        

        public function index()
	{
                $this->load->view('navbar');
                $this->load->view('hlavniStranka');
	}
        public function __construct()
	{
	//call CodeIgniter's default Constructor
	parent::__construct();
	
	//load database libray manually
	$this->load->database();
	
	//load Model
	$this->load->model('model');
	}



        
    
        
        
        
    
        
        
        
        
        
        

 }


<?php

class model extends CI_Model {


    public function __construct() {
        parent::__construct();
    }

    
    public function get_skoly() {
      //  $query = $this->db->get("skola"); 
        
        
        
        $query = 

        $this->db->select('skola.id id, skola.nazev nazev, mesto.nazev nazevMesta, skola.geolat geolat, skola.geolong geolong')
        ->from('skola')
        ->join('mesto','mesto = mesto.id')
        ->get();
        return $query->result();
        
    }



}